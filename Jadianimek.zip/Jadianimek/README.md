## SCRIPT SIMPLE BOT WHATSAPP


-----------------------------------------------------

<p align="center">
<img src="https://telegra.ph/file/f152177bf55c322885b92.jpg" alt="XD TEAM" width="100"/>


</p>
<p align="center">
<a href="#"><img title="XD TEAM V1" src="https://img.shields.io/badge/XD BOTZ WHATSAPP-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://youtube.com/@kurrxdofc"><img title="Author" src="https://img.shields.io/badge/Author-KurrXd-red.svg?style=for-the-badge&logo=youtube"></a>
</p>
<p align="center">
<a href="https://github.com/xd-team-botz/followers"><img title="Followers" src="https://img.shields.io/github/followers/xd-team-botz?color=red&style=flat-square"></a>
<a href="https://github.com/xd-team-botz/xdbotz-v1/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/xd-team-botz/xdbotz-v1?color=blue&style=flat-square"></a>
<a href="https://github.com/xd-team-botz/xdbotz-v1/network/members"><img title="Forks" src="https://img.shields.io/github/forks/xd-team-botz/xdbotz-v1?color=red&style=flat-square"></a>
<a href="https://github.com/xd-team-botz/xdbotz-v1/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/xd-team-botz/xdbotz-v1?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/xd-team-botz/xdbotz-v1"><img title="Open Source" src="https://badges.frapsoft.com/os/v2/open-source.svg?v=103"></a>
<a href="https://github.com/xd-team-botz/xdbotz-v1/"><img title="Size" src="https://img.shields.io/github/repo-size/xd-team-botz/xdbotz-v1?style=flat-square&color=green"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fxd-team-botz%2Fxdbotz-v1&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
<a href="https://github.com/xd-team-botz/xdbotz-v1/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>
</div>

---

## DOWNLOAD :
[klik ini untuk download zip](https://github.com/xd-team-botz/xdbotz-v1/archive/refs/heads/main.zip)

## OFFICIAL GROUP 
[klik ini untuk gabung](https://chat.whatsapp.com/FSALEynItwA0rMyLIgBA8M)

## DEVELOPER THIS PROJECT
- Me (KurrXd)



