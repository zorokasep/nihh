const fs = require('fs')
const chalk = require('chalk')
// EDIT DISINI
global.owner = ['6285813708397'] // no own
global.author = '𝙁𝙖𝙡𝙡 𝙃𝙤𝙨𝙩' // nama author 
global.packname = '𝙁𝙖𝙡𝙡 𝙃𝙤𝙨𝙩' // nama pack sticker
global.namabot = '𝘾𝙮𝙘𝙡𝙤𝙣𝙞𝙡𝙚' // nama bot mu
global.group = 'https://chat.whatsapp.com/KCYr0YwODJTEEFUlPxuNXQ' // grup mu



let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.yellowBright(`Update File Terbaru ${__filename}`))
delete require.cache[file]
require(file)
})
